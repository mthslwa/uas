package com.example.tugas11;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    private View btnAcc = findViewById(R.id.accinfo);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAcc = findViewById(R.id.accinfo);

        btnAcc.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), accinfo.class));
        });
    }
}