package com.example.tugas11;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class login extends AppCompatActivity {
    private View btnSignUp = findViewById(R.id.btn_sign);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);
        btnSignUp = findViewById(R.id.btn_sign);

        btnSignUp.setOnClickListener(v -> {
            startActivity(new Intent(getApplicationContext(), sign.class));
        });
    }
}
