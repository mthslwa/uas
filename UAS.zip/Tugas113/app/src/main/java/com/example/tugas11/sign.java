package com.example.tugas11;

public interface sign {
}
